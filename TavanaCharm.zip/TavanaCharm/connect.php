<?php
$db=mysqli_connect("%","shaghayegh","0024242731","Tavana_charm_db");
if (!$db){
	die("connection failed".mysqli_connect_error());
}
$db->set_charset('utf8');

?>