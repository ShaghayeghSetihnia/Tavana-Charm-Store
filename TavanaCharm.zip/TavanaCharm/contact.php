﻿<?php
if(array_key_exists('btn_submit',$_POST)){
    if(array_key_exists('stu_file',$_FILES)){
        $file=$_FILES['stu_file'];
        //print_r($file);
        $name=$file['name'];
        $tmp_name=$file['tmp_name'];
        $url="uploads/".$name;
        if(file_exists("uploads/".$name)) echo "already exist";
        else move_uploaded_file($tmp_name,"uploads/".$name);
    }
$des=test_input($_POST['p_description']);
$category=test_input($_POST['p_category']);
    include('db/connect.php');
$query="INSERT INTO Commentt( p_url, p_description, p_category) VALUES ('$url','$des','$category')";
    $db->query($query);
    $db->close();
    header('location:admin.php');
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>



<!DOCTYPE html>
<!--[if lt IE 8]>      <html class="no-js lt-ie10 lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie10 lt-ie9"> <![endif]-->
<!--[if IE 9]>         <html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
  <head>
    <meta charset="utf-8">
    <title>تماس با ما</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">

    <!--  Google Fonts  -->
    <link href='http://fonts.googleapis.com/css?family=Pacifico|Open+Sans:400,700,400italic,700italic&amp;subset=latin,latin-ext,greek' rel='stylesheet' type='text/css'>
    
    <!-- Twitter Bootstrap -->
    <link href="stylesheets/bootstrap.css" rel="stylesheet">
    <link href="stylesheets/responsive.css" rel="stylesheet">
    <!-- Slider Revolution -->
    <link rel="stylesheet" href="js/rs-plugin/css/settings.css" type="text/css"/>
    <!-- jQuery UI -->
    <link rel="stylesheet" href="js/jquery-ui-1.10.3/css/smoothness/jquery-ui-1.10.3.custom.min.css" type="text/css"/>
    <!-- PrettyPhoto -->
    <link rel="stylesheet" href="js/prettyphoto/css/prettyPhoto.css" type="text/css"/>
    <!-- main styles -->
     
    <link href="stylesheets/main.css" rel="stylesheet">
     
    

    <!-- Modernizr -->
    <script src="js/modernizr.custom.56918.js"></script>    

    <!-- Fav and touch icons -->
    <link rel="shortcut icon" href="logo.png">
  </head>

   
  <body class="">
    
    <div class="master-wrapper">
     
    <!--  ==========  -->
    <!--  = Header =  -->
    <!--  ==========  -->
    <header id="header">
              <div class="container">
            <div class="row">
                <div class="span7">
                    <a class="brand" href="index.html">
                        <img src="logo.png" alt="چرم توانا" width="48" height="48" /> 
                        <span class="tagline"><b>چرم توانا</b></span> 
                        <span class="tagline">با کیفیت ترین محصولات را از ما بخواهید!</span> 
                    </a>
                </div>
                <div class="span5">
                    <div class="topmost-line">
                        <div class="lang-currency">
                        </div>
                    </div>
                    <div class="top-right">
                        <div class="register">
                            <a href="#loginModal" role="button" data-toggle="modal">ورود</a> یا  
                            <a href="#registerModal" role="button" data-toggle="modal">ثبت نام</a>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
    </header>
    <div class="navbar navbar-static-top" id="stickyNavbar">
      <div class="navbar-inner">
        <div class="container">
          <div class="row">
            <div class="span9">
                <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                </button>
                <div class="nav-collapse collapse">
                  <ul class="nav" id="mainNavigation">
                        <li><a href="index.html">خانه</a></li>
                    <li class="dropdown">
                        <a href="shop-no-sidebar.html" class="dropdown-toggle">محصولات<b class="caret"></b> </a>
                        <ul class="dropdown-menu">
                            <li><a href="">زنانه</a></li>
                            <li><a href="">مردانه</a></li>
                        </ul>
                    </li>
                    <li><a href="about-us.html">درباره ما</a></li>
                  </ul>
                  <form class="navbar-form pull-right" action="#" method="get">
                      <button type="submit"><span class="icon-search" ></span></button>
                      <input type="text" class="span1" name="search" id="navSearchInput">
                  </form>
                </div>
            </div>
            <div class="span3">
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </header>
    <!--  ==========  -->
    <!--  = Breadcrumbs =  -->
    <!--  ==========  -->
    <div class="darker-stripe">
        <div class="container">
            <div class="row">
                <div class="span12">
                    <ul class="breadcrumb">
                        <li>
                            <a href="index.html">چرم توانا</a>
                        </li>
                        <li><span class="icon-chevron-right"></span></li>
                        <li>
                            <a href="contact.html">ارتباط با ما</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="push-up top-equal blocks-spacer-last">
            <div class="row">
                
                <!--  ==========  -->
                <!--  = Main Title =  -->
                <!--  ==========  -->
                
                <div class="span12">
                    <div class="title-area">
                        <h1 class="inline"><span class="light">با ما</span> ارتباط برقرار کنید.</h1>
                    </div>
                </div>
                
                <!--  ==========  -->
                <!--  = Main content =  -->
                <!--  ==========  -->
                <section class="span8 single single-page">
                    
                    <!--  ==========  -->
                    <!--  = Post =  -->
                    <!--  ==========  -->
                    <article class="post">
                        <div class="post-inner">
                            <p>
						
                            </p>
                        </div>
                    </article>
                    
                    <hr />
                    
                    <!--  ==========  -->
                    <!--  = Contact Form =  -->
                    <!--  ==========  -->
                    <section class="contact-form-container">
                        
                        <h3 class="push-down-25"><span class="light">ارسال</span> پیام</h3>
                        
                        <form id="commentform" method="post" action="#" class="form form-inline form-contact">
                            <p class="push-down-20">
                                <input type="text" aria-required="true" tabindex="1" size="30" value="" id="author" name="author" required>
                                <label for="author">نام<span class="red-clr bold">*</span></label>
                            </p>
                            <p class="push-down-20">
                                <input type="email" aria-required="true" tabindex="2" size="30" value="" id="email" name="email" required>
                                <label for="email">ایمیل<span class="red-clr bold">*</span></label>
                            </p>
                            <p class="push-down-20">
                                <input type="text" tabindex="3" size="30" value="" id="url" name="url">
                                <label for="url">وبسایت</label>
                            </p>
    
                            <p class="push-down-20">
                                <textarea class="input-block-level" tabindex="4" rows="7" cols="70" id="comment" name="comment" placeholder="پیامتان را در اینجا بنویسید ..." required></textarea>
                            </p>
                            <p>
                                <button class="btn btn-primary bold" type="submit" tabindex="5" id="submit" name="btn_submit">ارسال پیام</button>
                            </p>
                        </form>
                    </section>
                    
                    <hr />
                    
                    <!--  ==========  -->
                    <!--  = Company Info with Google Maps =  -->
                    <!--  ==========  -->
                    <article class="company-info">
                        <div class="row">
                        	<div class="span3">
                        		<h3 class="push-down-30"><span class="light">اطلاعات</span> تماس</h3>
                        		    
                        		
                        		    
                        		<p>
                        		    <strong class="opensans dark-clr">شماره تماس :</strong> 02833320291 
                        		    <br />
                        		    <strong class="opensans dark-clr">شماره تماس :</strong> 02833345222
                        		    <br />
                        		    <strong class="opensans dark-clr">ایمیل:</strong> <a href="#">tavanacharm@gmail.com</a>
                                    <br />
                                    <strong class="opensans dark-clr">آدرس :</strong> قزوین بلوار شهید بهشتی جنب سرزمین سحر آمیز کانون معلولین توانا شعبه قزوین
                        		</p>
                        	</div>
                        	
    
                    </article>

                </section> <!-- /main content -->
                
                <!--  ==========  -->
                <!--  = Sidebar =  -->
                <!--  ==========  -->
                <aside class="span4">
                    
                    <!--  ==========  -->
                    <!--  = Opening Times Widget =  -->
                    <!--  ==========  -->
                    <div class="sidebar-item opening-time" id="opening_time-4">
                        <div class="underlined">
                            <h3><span class="light">ساعات</span> کاری</h3>
                        </div>
                        <div class="time-table">
                            <dl class="week-day">
                                <dt>
                                    شنبه
                                </dt>
                                <dd>
                                    ۸:۰۰ - ۱۶:۰۰
                                </dd>
                            </dl>
                            <dl class="week-day light-bg">
                                <dt>
                                    یکشنبه
                                </dt>
                                <dd>
                                    ۸:۰۰ - ۱۶:۰۰
                                </dd>
                            </dl>
                            <dl class="week-day">
                                <dt>
                                    دوشنبه
                                </dt>
                                <dd>
                                    ۸:۰۰ - ۱۶:۰۰
                                </dd>
                            </dl>
                            <dl class="week-day light-bg today">
                                <dt>
                                    سه شنبه
                                </dt>
                                <dd>
                                    ۸:۰۰ - ۱۶:۰۰
                                </dd>
                            </dl>
                            <dl class="week-day">
                                <dt>
                                    چهارشنبه
                                </dt>
                                <dd>
                                    ۸:۰۰ - ۱۶:۰۰
                                </dd>
                            </dl>
                            <dl class="week-day light-bg">
                                <dt>
                                    پنج شنبه
                                </dt>
                                <dd>
                                    ۸:۰۰ - ۱۲:۰۰
                                </dd>
                            </dl>
                            <dl class="week-day closed">
                                <dt>
                                    جمعه
                                </dt>
                                <dd>
                                    تعطیل
                                </dd>
                            </dl>
                        </div>
                    </div>
                    
                    <!--  ==========  -->
                    <!--  = Twitter Widget =  -->
                    <!--  ==========  -->
                   
                    
                </aside> <!-- /sidebar -->

            </div>
        </div>
    </div> <!-- /container -->
    
     
    
     
    <!--  ==========  -->
    <!--  = Footer =  -->
    <!--  ==========  -->
    <footer>
        <!--  ==========  -->
        <!--  = Upper footer =  -->
        <!--  ==========  -->

        <div class="foot-dark">
            <div class="container">
                <div class="row">

        </div> <!-- /middle footer -->
        
        <!--  ==========  -->
        <!--  = Bottom Footer =  -->
        <!--  ==========  -->
        <div class="foot-last">
            <a href="#" id="toTheTop">
                <span class="icon-chevron-up"></span>
            </a>
            <div class="container">
                <div class="row">
                    <div class="span3">
                        <ul class="nav bold">
                            <li><a href="http://tavanacharm.com">سایت اصلی</a></li>
                            <li><a href="http://tavanacharm.com/%D9%82%D9%88%D8%A7%D9%86%DB%8C%D9%86-%D9%88-%D9%85%D9%82%D8%B1%D8%B1%D8%A7%D8%AA/">شرایط و قوانین</a></li>
                            <li><a href="http://tavanacharm.com/%D9%82%D9%88%D8%A7%D9%86%DB%8C%D9%86-%D9%88-%D9%85%D9%82%D8%B1%D8%B1%D8%A7%D8%AA/#">حریم خصوصی</a></li>
                        </ul>
                    </div>
                    <div class="span6">
                        &copy; ساخته شده توسط  <a target="_blank" href="http://tavanacharm.com/">چرم توانا </a>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </footer>

    </div> <!-- end of master-wrapper -->
    


    <!--  ==========  -->
    <!--  = JavaScript =  -->
    <!--  ==========  -->
    
    <!--  = FB =  -->
    
    <div id="fb-root"></div>
    <script>(function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=126780447403102";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>
    
    
    <!--  = jQuery - CDN with local fallback =  -->
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript">
    if (typeof jQuery == 'undefined') {
        document.write('<script src="js/jquery.min.js"><\/script>');
    }
    </script>
    
    <!--  = _ =  -->
    <script src="js/underscore/underscore-min.js" type="text/javascript"></script>
    
    <!--  = Bootstrap =  -->
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    
    <!--  = Slider Revolution =  -->
    <script src="js/rs-plugin/pluginsources/jquery.themepunch.plugins.min.js" type="text/javascript"></script>
    <script src="js/rs-plugin/js/jquery.themepunch.revolution.min.js" type="text/javascript"></script>
    
    <!--  = CarouFredSel =  -->
    <script src="js/jquery.carouFredSel-6.2.1-packed.js" type="text/javascript"></script>
    
    <!--  = jQuery UI =  -->
    <script src="js/jquery-ui-1.10.3/js/jquery-ui-1.10.3.custom.min.js" type="text/javascript"></script>
    <script src="js/jquery-ui-1.10.3/touch-fix.min.js" type="text/javascript"></script>
    
    <!--  = Isotope =  -->
    <script src="js/isotope/jquery.isotope.min.js" type="text/javascript"></script>
    
    <!--  = Tour =  -->
    <script src="js/bootstrap-tour/build/js/bootstrap-tour.min.js" type="text/javascript"></script>
    
    <!--  = PrettyPhoto =  -->
    <script src="js/prettyphoto/js/jquery.prettyPhoto.js" type="text/javascript"></script>
    
    <!--  = Google Maps API =  -->
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
    <script type="text/javascript" src="js/goMap/js/jquery.gomap-1.3.2.min.js"></script>
    
    <!--  = Custom JS =  -->
    <script src="js/custom.js" type="text/javascript"></script>

  </body>
</html>

    
    